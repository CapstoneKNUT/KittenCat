import React from "react";
import BasicLayout from '../layout/BasicLayout';


function MainPage(props){
    return(
        <BasicLayout>
            <div>Main Page</div>
        </BasicLayout>
    );
}
export default MainPage;